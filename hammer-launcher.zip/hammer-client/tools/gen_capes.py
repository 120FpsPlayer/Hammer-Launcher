#!/usr/bin/env python3
"""Draws the Hammer+ capes (the standard Minecraft cape layout, 8× the usual 64×32 so the logo stays sharp).

    python3 tools/gen_capes.py [--mod-only]

Writes the textures and the list (id, Polish and English name, free = for everybody) for the mod and for the
launcher's cape picker (--mod-only: just the mod's):
    common/src/main/resources/assets/hammerclient/textures/capes/<id>.png + assets/hammerclient/capes.json
    ../hammer-launcher/src/renderer/assets/capes/<id>.png + capes.json
The lists also name the moving capes of gen_cosmetics.py (frames, fps: their textures are strips of frames).
The logo comes from gen_logo.py (tools/brand/mark.svg).
"""
import json
import os
import random
import sys

from PIL import Image, ImageDraw, ImageFilter

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.dont_write_bytecode = True  # the two generators import each other – no __pycache__ in the repository
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
MOD = os.path.join(ROOT, 'common/src/main/resources/assets/hammerclient')
LAUNCHER = os.path.join(ROOT, '..', 'hammer-launcher', 'src', 'renderer', 'assets', 'capes')
MOD_ONLY = '--mod-only' in sys.argv  # leave the launcher's copies alone
S = 8  # pixels per texel of the 64×32 layout

# id: (Polish name, English name, top colour, bottom colour, logo tint or None = the logo's own colours, trim colour)
CAPES = {
    'hammer': ('Hammer', 'Hammer', (16, 13, 9), (34, 24, 10), None, (255, 196, 0)),
    'gold': ('Złota', 'Gold', (255, 214, 60), (224, 132, 0), (38, 22, 0), (70, 40, 0)),
    'ember': ('Żar', 'Ember', (20, 10, 6), (232, 96, 10), (255, 232, 170), (255, 150, 40)),
    'royal': ('Królewska', 'Royal', (44, 16, 92), (18, 8, 44), None, (255, 205, 70)),
    'frost': ('Mróz', 'Frost', (10, 26, 60), (60, 190, 235), (240, 250, 255), (190, 240, 255)),
    'crimson': ('Karmazyn', 'Crimson', (120, 10, 18), (16, 6, 8), None, (255, 196, 0)),
}
# The capes everybody may wear – no Hammer+ needed (the shop's server and the mod say the same).
FREE = {'hammer', 'ember'}


def lerp(a, b, t):
    return tuple(round(a[i] + (b[i] - a[i]) * t) for i in range(3))


def gradient(w, h, top, bottom):
    im = Image.new('RGBA', (w, h))
    px = im.load()
    for y in range(h):
        c = lerp(top, bottom, y / max(1, h - 1))
        for x in range(w):
            px[x, y] = (*c, 255)
    return im


def logo(width, tint):
    """The logo `width` pixels wide; with a tint, in that one colour – its faces still lighter and darker, so the
    voxels show (a light tint gets darker on the shaded faces, a dark one lighter on the lit ones)."""
    import gen_logo  # the same folder
    src = gen_logo.mark_cropped(width)
    if tint is None:
        return src
    px = src.load()
    lum = {(x, y): (0.299 * px[x, y][0] + 0.587 * px[x, y][1] + 0.114 * px[x, y][2]) / 255 for y in range(src.height) for x in range(src.width)}
    top = max(v for (x, y), v in lum.items() if px[x, y][3] > 128)
    dark = sum(tint) < 300
    out = Image.new('RGBA', src.size)
    o = out.load()
    for (x, y), v in lum.items():
        shade = 1 - min(1.0, v / top)  # 0 on the brightest face
        c = lerp(tint, (255, 255, 255), 0.2 * (1 - shade)) if dark else lerp(tint, (0, 0, 0), 0.4 * shade)
        o[x, y] = (*c, px[x, y][3])
    return out


def cape(cid):
    _, _, top, bottom, tint, trim = CAPES[cid]
    im = Image.new('RGBA', (64 * S, 32 * S), (0, 0, 0, 0))
    rnd = random.Random(cid)

    def paste(x, y, w, h, t0=0.0, t1=1.0):
        im.paste(gradient(w * S, h * S, lerp(top, bottom, t0), lerp(top, bottom, t1)), (x * S, y * S))

    paste(1, 0, 10, 1, 0, 0)        # top edge
    paste(11, 0, 10, 1, 1, 1)       # bottom edge
    paste(0, 1, 1, 16)              # right edge
    paste(11, 1, 1, 16)             # left edge
    paste(1, 1, 10, 16)             # outside – what others see from behind
    inner = gradient(10 * S, 16 * S, lerp(top, (0, 0, 0), 0.35), lerp(bottom, (0, 0, 0), 0.45))
    im.paste(inner, (12 * S, 1 * S))  # inside
    paste(22, 0, 24, 22)            # elytra wings use this part of the cape texture

    d = ImageDraw.Draw(im)
    x0, y0, w, h = 1 * S, 1 * S, 10 * S, 16 * S
    # a few sparks in the cape's trim colour
    for _ in range(26):
        sx, sy = x0 + rnd.randrange(4, w - 4), y0 + rnd.randrange(h // 2, h - 6)
        d.point((sx, sy), fill=(*trim, rnd.randrange(90, 200)))
    # trim: a frame and a double bar at the bottom
    d.rectangle((x0 + 2, y0 + 2, x0 + w - 3, y0 + h - 3), outline=(*trim, 255), width=2)
    d.rectangle((x0 + 8, y0 + h - 16, x0 + w - 9, y0 + h - 14), fill=(*trim, 255))
    d.rectangle((x0 + 14, y0 + h - 11, x0 + w - 15, y0 + h - 10), fill=(*trim, 200))
    # the logo, with a soft glow behind it
    mark = logo(w - 22, tint)
    glow = Image.new('RGBA', im.size, (0, 0, 0, 0))
    gx, gy = x0 + (w - mark.width) // 2, y0 + 16
    halo = Image.new('RGBA', mark.size, (*trim, 150))
    halo.putalpha(mark.getchannel('A').point(lambda a: a * 150 // 255))
    glow.paste(halo, (gx, gy), halo)
    im.alpha_composite(glow.filter(ImageFilter.GaussianBlur(5)))
    im.alpha_composite(mark, (gx, gy))
    # elytra: the same frame so wings match the cape
    ex, ey, ew, eh = 22 * S, 0, 24 * S, 22 * S
    d.rectangle((ex + 2, ey + 2, ex + ew - 3, ey + eh - 3), outline=(*trim, 255), width=2)
    return im


def write_lists():
    """capes.json for the mod and the launcher: the still capes, then the moving ones (gen_cosmetics.py)."""
    import gen_cosmetics  # the same folder
    listing = [{'id': cid, 'name': CAPES[cid][0], 'nameEn': CAPES[cid][1], **({'free': True} if cid in FREE else {})} for cid in CAPES]
    listing += [{'id': cid, 'name': pl, 'nameEn': en, 'frames': gen_cosmetics.FRAMES, 'fps': gen_cosmetics.FPS} for cid, (pl, en, _) in gen_cosmetics.ANIMATED.items()]
    for index in [os.path.join(MOD, 'capes.json')] + ([] if MOD_ONLY else [os.path.join(LAUNCHER, 'capes.json')]):
        with open(index, 'w', encoding='utf-8') as f:
            json.dump(listing, f, ensure_ascii=False, indent=2)
            f.write('\n')


def main():
    for out in [os.path.join(MOD, 'textures', 'capes')] + ([] if MOD_ONLY else [LAUNCHER]):
        os.makedirs(out, exist_ok=True)
        for cid in CAPES:
            cape(cid).save(os.path.join(out, cid + '.png'), optimize=True)
    write_lists()
    print(f'{len(CAPES)} capes → mod' + ('' if MOD_ONLY else ' and launcher'))


if __name__ == '__main__':
    main()
