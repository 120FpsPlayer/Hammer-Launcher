package pl.hammershop.client.module.hud;

import pl.hammershop.client.module.HudCanvas;
import pl.hammershop.client.module.HudModule;
import pl.hammershop.client.module.Setting;

/** The Hammer logo in a corner of the screen (off by default). */
public final class Watermark extends HudModule {
    private final Setting.Bool name = bool("show_name", true);
    private final Setting.Color text = color("text_color", 0xFFFFFFFF, true);

    public Watermark() {
        super("watermark", "hammer", false, Anchor.BOTTOM_LEFT);
    }

    @Override
    protected void draw(HudCanvas c) {
        c.d.pixelLogo(1, 1, 14, 0xFFFFFFFF, true); // pixel art like the game's own font next to it
        float w = 16;
        if (name.on()) {
            w = c.text("Hammer Client", 18, 4, text.argb(), true);
            if (pl.hammershop.client.Hammer.plus()) w = c.text("+", w, 4, 0xFFFFC83D, true);
            w += 3;
        }
        c.size(w, 16);
    }
}
