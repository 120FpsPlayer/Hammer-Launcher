'use strict';

/**
 * Microsoft accounts (the only way to play Minecraft Java Edition legally). Login opens Microsoft's own page in a
 * small window (msmc); the launcher keeps the refresh token encrypted with the system keychain (Electron safeStorage)
 * and refreshes the game token by itself before each start. Accounts without Minecraft Java are refused.
 */

const crypto = require('node:crypto');
const { readJson, writeJson } = require('./store');
const { isNetworkError } = require('./net');

const ERRORS = {
  'error.gui.closed': 'Okno logowania zostało zamknięte.',
  'error.auth.microsoft': 'Nie udało się zalogować do konta Microsoft. Spróbuj ponownie.',
  'error.auth.xboxLive': 'Nie udało się połączyć z Xbox Live. Spróbuj ponownie za chwilę.',
  'error.auth.xsts.userNotFound': 'To konto Microsoft nie ma profilu Xbox. Załóż go na xbox.com i spróbuj ponownie.',
  'error.auth.xsts.bannedCountry': 'Xbox Live nie działa w kraju tego konta.',
  'error.auth.xsts.child': 'To konto dziecka – dorosły musi dodać je do rodziny Microsoft, żeby można było grać.',
  'error.auth.xsts.child.SK': 'To konto wymaga zgody rodzica na stronie Xbox.',
  'error.auth.minecraft.login': 'Mojang odrzucił logowanie. Spróbuj ponownie za chwilę.',
  'error.auth.minecraft.profile': 'To konto nie ma kupionego Minecraft: Java Edition.',
  'error.auth.minecraft.entitlements': 'Nie udało się sprawdzić, czy konto ma Minecrafta.',
};

/** No connection (offline, DNS, a dropped line) – not a reason to sign in again: the stored login still holds. */
const OFFLINE = 'Nie udało się połączyć z serwerami Microsoft – sprawdź internet i spróbuj ponownie.';
/** Microsoft or Xbox said no to this account – only then must the player sign in again (a busy service is not that). */
const AUTH_REJECTED = ['error.auth.microsoft', 'error.auth.xsts', 'error.auth.minecraft.profile'];
const rejected = (err) => {
  const code = typeof err === 'string' ? err : err?.ts ?? err?.name ?? '';
  return typeof code === 'string' && AUTH_REJECTED.some((k) => code === k || code.startsWith(`${k}.`));
};

/** msmc errors are strings ("error.gui.closed") or { ts: 'error.auth…' } – Polish text for the window. */
function loginError(err) {
  const code = typeof err === 'string' ? err : err?.ts ?? err?.name ?? err?.message;
  if (code && ERRORS[code]) return ERRORS[code];
  const parent = code && Object.keys(ERRORS).find((k) => code.startsWith(k));
  if (parent) return ERRORS[parent];
  return `Logowanie nie powiodło się${err?.message ? `: ${err.message}` : '.'}`;
}

// Mojang hands out http:// skin links; textures.minecraft.net also serves them over https.
const httpsUrl = (url) => (typeof url === 'string' ? url.replace(/^http:\/\//, 'https://') : null);
const activeSkin = (profile) => (profile?.skins ?? []).find((s) => s.state === 'ACTIVE') ?? profile?.skins?.[0] ?? null;

/**
 * @param {object} o
 * @param {string} o.file accounts.json
 * @param {{ encrypt(text: string): string, decrypt(text: string): string }} o.crypt  safeStorage wrapper
 * @param {object} o.config launcher.config.json (microsoft.clientId for your own Azure app)
 * @param {Function} [o.AuthClass] msmc Auth (injected in tests)
 */
function createAccounts({ file, crypt, config = {}, AuthClass, windowProperties }) {
  const Auth = AuthClass ?? require('msmc').Auth;
  // (A file that is JSON but not a list of accounts – cut off, edited by hand – counts as "nobody signed in":
  // without this the launcher would not even start.)
  const stored = readJson(file, null);
  let state = { accounts: Array.isArray(stored?.accounts) ? stored.accounts.filter((a) => a && typeof a === 'object' && typeof a.id === 'string') : [] };
  const save = () => writeJson(file, state);

  function makeAuth() {
    const clientId = config.microsoft?.clientId;
    if (!clientId) return new Auth('select_account');
    return new Auth({ client_id: clientId, redirect: config.microsoft.redirect || 'https://login.live.com/oauth20_desktop.srf', prompt: 'select_account' });
  }

  function publicInfo(a) {
    return { id: a.id, name: a.name, skinUrl: httpsUrl(a.skinUrl), skinVariant: a.skinVariant ?? 'CLASSIC', addedAt: a.addedAt, needsLogin: Boolean(a.needsLogin) };
  }

  function store(mc, refreshToken) {
    if (!mc?.profile?.id || mc.profile.demo) throw new Error(ERRORS['error.auth.minecraft.profile']);
    const skin = activeSkin(mc.profile);
    const record = {
      id: mc.profile.id,
      name: mc.profile.name,
      skinUrl: httpsUrl(skin?.url),
      skinVariant: skin?.variant ?? 'CLASSIC',
      xuid: mc.xuid ?? null,
      refresh: crypt.encrypt(refreshToken),
      token: crypt.encrypt(mc.mcToken),
      exp: mc.exp ?? Date.now() + 23 * 3600 * 1000,
      addedAt: state.accounts.find((a) => a.id === mc.profile.id)?.addedAt ?? Date.now(),
      needsLogin: false,
    };
    state.accounts = [record, ...state.accounts.filter((a) => a.id !== record.id)];
    save();
    return publicInfo(record);
  }

  return {
    list: () => state.accounts.map(publicInfo),

    /** Opens the Microsoft login window; resolves with the new account or throws a Polish message. */
    async login() {
      try {
        const xbox = await makeAuth().launch('electron', windowProperties);
        const mc = await xbox.getMinecraft();
        return store(mc, xbox.save());
      } catch (err) {
        if (err instanceof Error && Object.values(ERRORS).includes(err.message)) throw new Error(err.message);
        // The connection dropped between Microsoft's page and Xbox / Minecraft: said like at a start of the game.
        throw new Error(typeof err !== 'string' && !err?.ts && isNetworkError(err) ? OFFLINE : loginError(err), { cause: err });
      }
    },

    remove(id) {
      state.accounts = state.accounts.filter((a) => a.id !== id);
      save();
      return true;
    },

    /** The skin shown next to the account (after the player changed it in the Skórka tab). */
    setSkin(id, { skinUrl = null, skinVariant = 'CLASSIC' } = {}) {
      const account = state.accounts.find((a) => a.id === id);
      if (!account) return null;
      account.skinUrl = httpsUrl(skinUrl);
      account.skinVariant = String(skinVariant).toUpperCase() === 'SLIM' ? 'SLIM' : 'CLASSIC';
      save();
      return publicInfo(account);
    },

    /**
     * { id, name, accessToken } for a launch – refreshes the game token when it is about to expire, or right away
     * with `force` (the Minecraft services refused the stored one).
     */
    async launchAuth(id, { force = false } = {}) {
      const account = state.accounts.find((a) => a.id === id) ?? state.accounts[0];
      if (!account) throw new Error('Zaloguj się kontem Microsoft w zakładce Konta.');
      if (!force && account.exp - Date.now() > 5 * 60 * 1000 && account.token) {
        try {
          return { id: account.id, name: account.name, accessToken: crypt.decrypt(account.token) };
        } catch {
          // the keychain changed (e.g. another Windows user) – refresh below
        }
      }
      let refresh;
      try {
        refresh = crypt.decrypt(account.refresh);
      } catch (err) {
        // The stored sign-in cannot be read on this computer any more (the launcher folder came from another
        // computer or Windows user, the system keychain was reset). Trying again never helps – a new sign-in does.
        account.needsLogin = true;
        save();
        throw new Error(`Sesja konta ${account.name} wygasła – zaloguj się ponownie w zakładce Konta.`, { cause: err });
      }
      try {
        const xbox = await makeAuth().refresh(refresh);
        const mc = await xbox.getMinecraft();
        const info = store(mc, xbox.save());
        return { id: info.id, name: info.name, accessToken: mc.mcToken };
      } catch (err) {
        // Offline or a busy Microsoft / Xbox service: the next try may just work – the account keeps its login.
        if (isNetworkError(err) || !rejected(err)) throw new Error(isNetworkError(err) ? OFFLINE : loginError(err), { cause: err });
        account.needsLogin = true;
        save();
        throw new Error(`Sesja konta ${account.name} wygasła – zaloguj się ponownie w zakładce Konta.`, { cause: err });
      }
    },
  };
}

/** Encryption with Electron's safeStorage (Windows DPAPI, macOS Keychain, libsecret) – a local key file as a fallback. */
function createCrypt({ safeStorage, keyFile, readKey, writeKey }) {
  const secure = Boolean(safeStorage?.isEncryptionAvailable?.());
  let k = null;
  const key = () => {
    if (k) return k;
    let hex = readKey?.(keyFile);
    if (!hex) {
      hex = crypto.randomBytes(32).toString('hex');
      writeKey?.(keyFile, hex);
    }
    k = Buffer.from(hex, 'hex');
    return k;
  };
  return {
    secure,
    encrypt(text) {
      if (secure) return `s:${safeStorage.encryptString(String(text)).toString('base64')}`;
      const iv = crypto.randomBytes(12);
      const c = crypto.createCipheriv('aes-256-gcm', key(), iv);
      const enc = Buffer.concat([c.update(String(text), 'utf8'), c.final()]);
      return `k:${Buffer.concat([iv, c.getAuthTag(), enc]).toString('base64')}`;
    },
    decrypt(data) {
      const text = String(data);
      if (text.startsWith('s:')) return safeStorage.decryptString(Buffer.from(text.slice(2), 'base64'));
      if (!text.startsWith('k:')) throw new Error('Unknown token format');
      const raw = Buffer.from(text.slice(2), 'base64');
      const d = crypto.createDecipheriv('aes-256-gcm', key(), raw.subarray(0, 12));
      d.setAuthTag(raw.subarray(12, 28));
      return Buffer.concat([d.update(raw.subarray(28)), d.final()]).toString('utf8');
    },
  };
}

module.exports = { createAccounts, createCrypt, loginError, isNetworkError, ERRORS, OFFLINE };
