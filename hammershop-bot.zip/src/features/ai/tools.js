'use strict';

/**
 * The AI assistant's tools – JSON-schema definitions (strict) and what they do.
 *
 * The list is fixed and always in the same order (it is the very start of the cached prompt). Every tool acts on the
 * ticket's owner only: the owner's ID comes from the ticket record (ctx.ownerId), never from the model's input – no
 * tool takes a user, so nothing can be granted to anyone else whatever a user writes. Inputs are validated here as
 * well (strict schemas are not a reason to trust them).
 *
 * ctx (from aiassistant.js): { guild, channel, ticket, ownerId, botId, escalate(reason, opts), deliverCode(granted) }
 */

const hammerplus = require('../hammerplus');
const launcherinfo = require('../launcherinfo');
const prizes = require('./prizes');
const { money, truncate } = require('../../lib/utils');

const NICK = /^[A-Za-z0-9_]{1,16}$/;

const object = (properties, required = []) => ({ type: 'object', properties, required, additionalProperties: false });

const TOOLS = [
  {
    name: 'info_launchera',
    description:
      'Aktualna wersja Hammer Launchera (numer, data, lista zmian), link do strony z pobieraniem, cennik Hammer+ i status Hammer+ autora ticketu. ' +
      'Podaj nick, żeby sprawdzić Hammer+ konkretnego konta Minecraft. Użyj, gdy ktoś pyta o wersję, pobieranie, ceny Hammer+ albo o to, czy jego Hammer+ działa.',
    strict: true,
    input_schema: object({ nick: { type: 'string', description: 'Nick Minecraft do sprawdzenia (opcjonalnie)' } }),
  },
  {
    name: 'moje_wygrane',
    description:
      'Giveawaye autora ticketu: wygrane (z ID, nagrodą i statusem odbioru), te, w których bierze udział, i ostatnie bez wygranej. ' +
      'Użyj, zanim cokolwiek powiesz o wygranej, nagrodzie albo giveawayu.',
    strict: true,
    input_schema: object({}),
  },
  {
    name: 'odbierz_nagrode',
    description:
      'Wydaje autorowi ticketu nagrodę z giveawayu, który wygrał (ID z moje_wygrane). Bot sam sprawdza wygraną, koniec giveawayu i to, czy nagroda nie została już odebrana. ' +
      'Hammer+ jest wydawany od razu na podany nick Minecraft (Java Edition); inne nagrody bot zgłasza zespołowi i woła go do ticketu.',
    strict: true,
    input_schema: object(
      {
        giveawayId: { type: 'string', description: 'ID giveawayu z moje_wygrane' },
        minecraftNick: { type: 'string', description: 'Nick Minecraft (Java Edition), na który ma być kod – potrzebny, gdy nagrodą jest Hammer+' },
      },
      ['giveawayId'],
    ),
  },
  {
    name: 'wezwij_zespol',
    description:
      'Woła zespół do ticketu (ping) i wyłącza asystenta w tym tickecie. Użyj, gdy ktoś prosi o człowieka, sprawa dotyczy pieniędzy, płatności, zwrotu albo bezpieczeństwa konta, ' +
      'zgłoszenie/odwołanie/podanie jest kompletne albo nie umiesz pomóc.',
    strict: true,
    input_schema: object({ powod: { type: 'string', description: 'Jedno–dwa zdania dla zespołu: czego dotyczy sprawa (bez ocen)' } }, ['powod']),
  },
];

/**
 * The same tools, worded short – for the free providers, which count every token. Fewer tools too: a reward ticket gets
 * the prize tools, every other ticket only the version / price lookup; all of them can call the team.
 */
const TOOLS_COMPACT = {
  info_launchera: {
    name: 'info_launchera',
    description: 'Aktualna wersja launchera, link do pobrania, cennik Hammer+ i status Hammer+ autora (albo podanego nicku).',
    input_schema: object({ nick: { type: 'string' } }),
  },
  moje_wygrane: { name: 'moje_wygrane', description: 'Wygrane giveawaye autora ticketu i status odbioru.', input_schema: object({}) },
  odbierz_nagrode: {
    name: 'odbierz_nagrode',
    description: 'Wydaje nagrodę z wygranego giveawayu (ID z moje_wygrane). Hammer+ wymaga nicku Minecraft.',
    input_schema: object({ giveawayId: { type: 'string' }, minecraftNick: { type: 'string' } }, ['giveawayId']),
  },
  wezwij_zespol: { name: 'wezwij_zespol', description: 'Woła zespół do ticketu. Potem nic nie pisz.', input_schema: object({ powod: { type: 'string' } }, ['powod']) },
};

/** The compact tool list for a ticket type. */
const toolsFor = (typeId) => (typeId === 'reward' ? ['moje_wygrane', 'odbierz_nagrode', 'wezwij_zespol'] : ['wezwij_zespol', 'info_launchera']).map((name) => TOOLS_COMPACT[name]);

/** Checks the input against the tool's schema (no extra keys, required present, strings only) → error text or null. */
function invalid(tool, input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) return 'Dane narzędzia muszą być obiektem.';
  const { properties, required } = tool.input_schema;
  for (const key of Object.keys(input)) if (!(key in properties)) return `Nieznane pole: ${key}. Narzędzie działa tylko na koncie autora ticketu.`;
  for (const key of required) if (input[key] === undefined || input[key] === null || input[key] === '') return `Brakuje pola: ${key}.`;
  for (const [key, value] of Object.entries(input)) {
    if (value !== null && typeof value !== 'string') return `Pole ${key} musi być tekstem.`;
    if (typeof value === 'string' && value.length > 400) return `Pole ${key} jest za długie.`;
  }
  return null;
}

const json = (value) => JSON.stringify(value);
const fail = (message) => ({ content: json({ ok: false, blad: message }), isError: true });
const done = (value) => ({ content: json({ ok: true, ...value }) });

/** "do 1 gru 2026, 18:00 (konto Notch)" – a Hammer+ end in unix seconds (0 = never, null = none). */
function untilText(until) {
  if (until === null || until === undefined) return null;
  if (until === 0) return 'aktywny na zawsze';
  return `aktywny do ${new Date(until * 1000).toLocaleString('pl-PL', { timeZone: 'Europe/Warsaw', dateStyle: 'medium', timeStyle: 'short' })}`;
}

/** The owner's own Hammer+ – every Minecraft account issued for their Discord account. */
function ownPlus(guildId, userId) {
  const accounts = new Map();
  for (const c of hammerplus.codes(guildId)) if (c.discordId === userId) accounts.set(c.mc, c.nick);
  const running = [...accounts].map(([mc, nick]) => ({ nick, until: hammerplus.runningUntil(guildId, mc) })).filter((a) => a.until !== null);
  if (!running.length) return 'brak aktywnego Hammer+ przypisanego do tego konta Discord';
  return running.map((a) => `${untilText(a.until)} (konto Minecraft ${a.nick})`).join('; ');
}

function plans() {
  try {
    const { currencyCode, DECIMALS } = require('../../lib/currency');
    const unit = 10 ** (DECIMALS[currencyCode() ?? 'eur'] ?? 2);
    return require('../../web/store')
      .plusPlans()
      .map((p) => ({ plan: p.name, czas: p.days === 0 ? 'na zawsze' : `${p.days} dni`, cena: money(p.price / unit) }));
  } catch {
    return [];
  }
}

async function infoLauncher(ctx, input) {
  const release = launcherinfo.currentRelease();
  const list = plans();
  const out = {
    wersja: release
      ? { numer: release.version, data: release.date.slice(0, 10), zmiany: truncate(release.notes || 'brak opisu', 600) }
      : 'brak danych o wersji (nic nie opublikowano albo strona jest wyłączona) – najnowszą wersję launcher pobiera sam',
    strona: launcherinfo.page() ?? 'https://hammerclient.com',
    hammer_plus_cennik: list.length ? list : 'cennik nie jest teraz dostępny – aktualne plany są na stronie launchera',
    hammer_plus_autora: ownPlus(ctx.guild.id, ctx.ownerId),
  };
  const nick = String(input.nick ?? '').trim();
  if (nick) {
    if (!NICK.test(nick)) out.hammer_plus_nicku = 'nieprawidłowy nick (najwyżej 16 znaków: litery, cyfry, _)';
    else {
      try {
        const account = await hammerplus.lookup(nick);
        const until = hammerplus.runningUntil(ctx.guild.id, account.mc);
        // The end date only for the author's own account – for anyone else just whether it runs (nobody's business when).
        const own = hammerplus.codes(ctx.guild.id).some((c) => c.mc === account.mc && c.discordId === ctx.ownerId);
        out.hammer_plus_nicku = { nick: account.nick, status: until === null ? 'brak aktywnego Hammer+' : own ? untilText(until) : 'Hammer+ aktywny' };
      } catch (err) {
        out.hammer_plus_nicku = err.message;
      }
    }
  }
  return done(out);
}

function myWins(ctx) {
  return done(prizes.winsOverview(ctx.guild.id, ctx.ownerId));
}

const REPORT_WHY = {
  other: 'to nie jest Hammer+',
  'unknown-length': 'to Hammer+, ale z nagrody nie wynika, na ile dni',
  late: 'minęło 48 godzin na odbiór',
  'rerolled-unclear': 'giveaway był losowany ponownie i nie wiadomo, kto jest teraz zwycięzcą',
  'no-key': 'bot nie może teraz wystawiać kodów Hammer+ (brak klucza)',
};

async function claimPrize(ctx, input) {
  const nick = input.minecraftNick ? String(input.minecraftNick).trim() : '';
  if (nick && !NICK.test(nick)) return fail('Nieprawidłowy nick Minecraft – najwyżej 16 znaków: litery, cyfry i podkreślenie (_). Poproś autora o poprawny nick.');
  const r = await prizes.claim({ guildId: ctx.guild.id, userId: ctx.ownerId, giveawayId: input.giveawayId, nick, botId: ctx.botId, channelId: ctx.channel.id });
  switch (r.result) {
    case 'not-found':
      return fail('Nie ma giveawayu o tym ID na tym serwerze. Sprawdź ID w moje_wygrane.');
    case 'not-ended':
      return fail(`Giveaway „${r.gw.prize}” jeszcze trwa – zwycięzców bot wylosuje, gdy skończy się czas.`);
    case 'not-winner':
      return fail(`Autor ticketu nie jest zwycięzcą giveawayu „${r.gw.prize}”. Nagrody nie można wydać.`);
    case 'rerolled':
      return fail(`Po ponownym losowaniu nagroda z giveawayu „${r.gw.prize}” przeszła na inną osobę – autor nie może jej odebrać. Jeśli uważa, że to pomyłka, wezwij zespół.`);
    case 'already':
      return fail(`Nagroda z giveawayu „${r.gw.prize}” została już ${r.claim.status === 'granted' ? `odebrana (kod Hammer+ dla konta ${r.claim.nick})` : 'zgłoszona zespołowi'} – drugi raz nie można jej wydać.`);
    case 'busy':
      return fail('Ta nagroda jest właśnie wydawana – poczekaj chwilę.');
    case 'need-nick':
      return fail('Nagrodą jest Hammer+ – potrzebny jest nick Minecraft (Java Edition), na który ma trafić kod. Zapytaj autora o nick i wywołaj narzędzie jeszcze raz.');
    case 'bad-nick':
      return fail(`Nie udało się sprawdzić nicku: ${r.error}`);
    case 'granted': {
      const dm = await ctx.deliverCode(r);
      return done({
        wydano: `Kod Hammer+ (${prizes.plusLength(r.days)}) dla konta Minecraft ${r.record.nick} – bot wysłał go w tickecie${dm ? ' i w wiadomości prywatnej' : '; wiadomość prywatna nie doszła (zamknięte DM), więc autor musi zachować kod z ticketu'}.`,
        dalej: 'Potwierdź krótko i przypomnij: launcher → Hammer+ → „Mam kod” → wklej → Aktywuj, na koncie, dla którego jest kod. Nie przepisuj kodu.',
      });
    }
    case 'reported':
      await ctx.escalate(`Nagroda do wydania ręcznie: „${r.gw.prize}” (giveaway ${r.gw.id}) – ${REPORT_WHY[r.why] ?? r.why}.`, { prize: r });
      return done({ zgloszono: 'Nagrodę zgłoszono zespołowi, który wyda ją ręcznie; zespół został zawołany do ticketu.' });
    default:
      return fail('Nie udało się wydać nagrody.');
  }
}

async function callTeam(ctx, input) {
  await ctx.escalate(String(input.powod ?? '').trim() || 'Asystent AI prosi zespół o pomoc.');
  return done({ zawolano: 'Zespół został zawołany do ticketu.' });
}

const RUN = { info_launchera: infoLauncher, moje_wygrane: myWins, odbierz_nagrode: claimPrize, wezwij_zespol: callTeam };

/** The answer to a tool call whose arguments weren't valid JSON (free models do that sometimes) – the model tries again. */
const brokenInput = () => fail('Argumenty narzędzia nie były poprawnym JSON-em. Wywołaj narzędzie jeszcze raz – argumenty muszą być jednym poprawnym obiektem JSON.');

/** Runs one tool_use block → { content (text for the tool_result), isError }. Never throws. */
async function runTool(name, input, ctx) {
  const tool = TOOLS.find((t) => t.name === name);
  if (!tool || (ctx.allowed && !ctx.allowed.has(name))) return fail(`Nie ma narzędzia ${name} w tym tickecie.`);
  const problem = invalid(tool, input);
  if (problem) return fail(problem);
  try {
    return await RUN[name](ctx, input);
  } catch (err) {
    console.error(`[asystent] narzędzie ${name}:`, err);
    return fail('Narzędzie nie zadziałało (błąd po stronie bota).');
  }
}

module.exports = { TOOLS, TOOLS_COMPACT, toolsFor, runTool, invalid, brokenInput, REPORT_WHY };
